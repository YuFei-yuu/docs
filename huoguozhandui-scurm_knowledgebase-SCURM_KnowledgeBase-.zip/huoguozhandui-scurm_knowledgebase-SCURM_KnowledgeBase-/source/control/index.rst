.. _control:

电控组
################

.. toctree::
   :maxdepth: 1

   chassis/index.rst
   gimbal/index.rst