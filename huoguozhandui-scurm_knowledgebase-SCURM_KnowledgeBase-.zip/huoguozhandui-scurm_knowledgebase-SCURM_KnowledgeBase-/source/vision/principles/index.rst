.. _vision_principles:

自瞄代码原理
################

.. toctree::
   :maxdepth: 1

   autoaim_detector.md
   autoaim_tracker.md

