# VSCode 推荐插件

## 效率作弊-Github Copilot

## 代码格式化-Prettier

## Cpp扩展-C/C++

## Python扩展-Python

## CMake扩展-CMake

## 远端开发-Remote Development、Remote - SSH

## 皮肤主题-Dracula Official、Material Theme、One Dark Pro

## Docker扩展-Docker

## 串口调试-Serial Port

## 模型浏览-vscode-3d-preview(导航看点云常用)



