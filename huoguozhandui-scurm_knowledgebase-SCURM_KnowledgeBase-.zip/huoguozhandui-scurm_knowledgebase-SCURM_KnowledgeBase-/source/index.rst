.. SCURM_KnowledgeBase documentation master file, created by
   sphinx-quickstart on Sun Apr 14 16:48:47 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SCURM_KnowledgeBase!
===============================================

.. toctree::
   :maxdepth: 2

   general/index.rst
   control/index.rst
   hardware/index.rst
   vision/index.rst
   navigation/index.rst
   mechanics/index.rst
   about/index.rst

初次编写文档先看**简明文档编写教程**👆
